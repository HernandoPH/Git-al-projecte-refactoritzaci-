<?php  
	session_start();
	include 'acesso_bd.php';

	$_sNombre = $_POST['nameCategory'];
		
	//Comprobamos que no exista esa categoria ya en la base de datos

	$comprobacionCategorias = "SELECT count(Categoria) FROM categorias WHERE Categoria LIKE '$_sNombre'";
	$ex = $dbh -> prepare($comprobacionCategorias);
	$ex -> execute();

	$fila = $ex->fetchColumn();
	if($fila == 0)
	{
		$queryCategory = "INSERT INTO categorias(Categoria) VALUES('$_sNombre')";
		$ejec = $dbh -> prepare($queryCategory);
		$ejec -> execute();	
		$_SESSION['categoriaInsertada'] = "La categoría se ha insertado correctamente";
	}
	else
	{
		$_SESSION['categoryExistente'] = "Esta Categoría ya existe en la base de datos";
	}
	header("Location:../View/admin.php");
	
?>