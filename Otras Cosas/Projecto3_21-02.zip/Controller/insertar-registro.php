<?php
	session_start();

	if (!empty($_POST["Nombre"])) {
            include 'acesso_bd.php';
    try {
	$username=$_POST["Nombre"];
	$FechaNacimiento=$_POST["FNacimiento"];
	$pass=$_POST["Password"];
	$correo=$_POST["Correo"];
    $direccion=$_POST["DPostal"];
    $Cposta=$_POST["CPostal"];
    $Tmovil=$_POST["TMovil"];
    $Tfijo=$_POST["TFijo"];
    
	$stmt = $dbh->prepare("SELECT Correo FROM usuarios WHERE Correo = ?");
	$stmt->execute( array($correo));
	if ($stmt->fetch(PDO::FETCH_ASSOC)) {
	}else{
	$stmt = $dbh->prepare("INSERT INTO usuarios(`Correo`,`Nombre`,`Password`, `Direccion`, `CodigoPostal`, `Movil`, `Fijo`, `Birthday`) VALUES(?,?,MD5(?),?,?,?,?,?)");
		$stmt->execute( array($correo,$username,$pass,$direccion,$Cposta,$Tmovil,$Tfijo,$FechaNacimiento));
		}
  } catch(PDOExecption $e) {
	print "Error!: " . $e->getMessage() . " deshacer</br>";
  }

}
?>