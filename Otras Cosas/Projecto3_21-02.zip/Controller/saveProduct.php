<?php  
	session_start();
	$nameProduct = $_POST['producto'];
	$priceProduct = $_POST['precio'];
	$stock = $_POST['cantidad'];
	$categoria = (int) $_POST['categorySelect'];
	
	insertData($nameProduct,$priceProduct,$stock,$categoria);

	function insertData($nameProduct,$priceProduct,$stock,$categoria)
	{
		include 'acesso_bd.php';
		//Comprobar si existe ese registro
		$comprobarProducto = "SELECT count(*) FROM productos WHERE Categoria LIKE $categoria AND Nombre_Producto LIKE '$nameProduct'";
		$exec = $dbh -> prepare($comprobarProducto);
		$exec->execute();
		$row = $exec -> fetchColumn();
		if($row == 0)
		{
			//Insertar registro
			$query = "INSERT INTO productos(Nombre_Producto,Precio_Producto,Stock,Categoria) VALUES('$nameProduct',$priceProduct,$stock,$categoria)";
			$ejec = $dbh-> prepare($query);
			$ejec->execute();
			$_SESSION['productoInsertado'] = "El producto ha sido insertado correctamente";
		}
		else
		{
			$_SESSION['mensajeExistente'] = "Este producto ya existe en la base de datos";
		}
		header("Location:../View/admin.php");
	}
?>