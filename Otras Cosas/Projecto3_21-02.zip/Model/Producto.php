<?php 

	class Producto
	{
		$Nombre;
		$precio;
		$descripcion;
	}
?>