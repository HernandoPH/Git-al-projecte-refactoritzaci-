<section>
	<div id="containerContact">
		<form>
			<div class="divCorreo">
				<label for="emailContact">Tu correo: </label>
				<input type="email" name="email" id="emailContact">
			</div>

			<div class="divMensaje">
				<label for="mensajeContact">Mensaje: </label>
				<textarea  id="mensajeContact"></textarea>
			</div>

			<div class="divTelefono">
				<label for="telefonoContact">Teléfono de Contacto: </label>
				<input type="tel" name="telefono" id="telefonoContact">
			</div>
		</form>
	</div>
</section>