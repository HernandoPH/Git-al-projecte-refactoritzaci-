function myFunction() {
 if(document.getElementById("navbar-right").style.display=="none"){
    document.getElementById("navbar-right").style.display="block";

 }else{
    document.getElementById("navbar-right").style.display="none";
 }
}
 