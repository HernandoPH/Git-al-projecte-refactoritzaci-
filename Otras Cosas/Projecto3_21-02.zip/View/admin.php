<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<script type="text/javascript" src="../Controller/js/admin.js"></script>
	<script type="text/javascript" src="../Controller/js/admin2.js"></script>
	<link rel="stylesheet" type="text/css" href="adminCss/admin.css">
</head>
<body>
	<div id="containerAdmin">
		<div class="containerFormsAdminProduct">
			<form action="../Controller/saveProduct.php" method="post" onsubmit="return validarProducto();">
				<fieldset class="fieldsetAdmin">
					<legend class="legendAdmin">Agregar un producto</legend>
					<label for="nameProduct">Nombre del producto:</label>
					<input class="input-registro" type="text" name="producto" id="nameProduct">
					<span class="errorEmpty"></span>
					<label for="priceProduct">Precio del producto:</label>
					<input class="input-registro" type="number" name="precio" id="priceProduct" step="0.01" min="1">
					<span class="errorEmpty"></span>
					<label for="stock">Stock: </label>
					<input class="input-registro" type="number" name="cantidad"  id="stock">
					<span class="errorEmpty"></span>
					<select name="categorySelect" class="input-registro">
						<option value="x">Elija una categoría</option>
						<?php  
							include '../Controller/acesso_bd.php';
							$queryCategories = "SELECT * FROM categorias";
							$exec = $dbh -> prepare($queryCategories);
							$exec -> execute();
							$camposCategoria = $exec->fetch(PDO::FETCH_ASSOC);
							?>
							<option value = <?php echo $camposCategoria['ID_Categoria']; ?>>
								<?php  

									echo $camposCategoria['Categoria'];

								?>
							</option>
					</select>
					<span class="errorEmpty"></span>
					<input  type="submit" name="enviarProducto" value="Enviar producto" class="input-registro">
					<?php session_start(); ?>
					<p>
						<?php  
							if(isset($_SESSION['mensajeExistente']))
							{
								echo "<h3 class='mensajeExistente'>".$_SESSION['mensajeExistente']."</h3>";	
							}
							if(isset($_SESSION['productoInsertado']))
							{
								echo "<h3 class='productoInsertado'>".$_SESSION['productoInsertado']."</h3>";
							}
							session_destroy();

						?>
					</p>
				</fieldset>
			</form>
		</div>
		<div class="containerFormsAdminCategory">
			<form action="../Controller/saveCategory.php" method="post" onsubmit="return categories();">
				<fieldset class="fieldsetAdmin">
					<legend class="legendAdmin">Agregar Categoría</legend>
					<label for="category">Nombre categoría</label>
					<input class="input-registro" type="text" name="nameCategory" id="category">
					<span class="errorEmpty"></span>
					<input class="input-registro" type="submit" name="enviarCategoria" value="Enviar categoría" class="actionsProducts">
					<?php session_start(); ?>
					<p>
							
					<?php  

						if(isset($_SESSION['categoryExistente']))
						{
							echo "<h3 class='mensajeExistente'>".$_SESSION['categoryExistente']."</h3>";
						}
						if(isset($_SESSION['categoriaInsertada']))
						{
							echo "<h3 class='productoInsertado'>".$_SESSION['categoriaInsertada']."</h3>";
						}
						session_destroy();

					?>

					</p>
				</fieldset>
			</form>
		</div>
	</div>
</body>
</html>