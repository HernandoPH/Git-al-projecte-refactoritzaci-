<?php 
    include("../Controller/insertar-registro.php");
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registro</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/registro.css">
    <link rel="stylesheet" type="text/css" href="css/principal.css">
    <link rel="stylesheet" type="text/css" href="../Styles/Plantilla_By_Danial.css">
    <link rel="icon" type="image/png" href="../img/1200px-PlayStation_logo.svg.png">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="./JavaScript/registro.js"></script>

</head>
<body>
   
    <?php  
        include 'header.php';
    ?>
     <div id="container-registro">
        <div id="Formulario-Registro">
            <h2 id="titulo-eventos-index">Registro de Usuario</h2>
            <form action="Registro.php" method="post" onsubmit="return checkRegistro()" >
                <table   class="registro">
                    <tr>
                        <td>
                            Nombre y Apellidos *<br/>
                            <input class="input-registro" type="text" id="Nombre" name="Nombre" >
                            <span class="span-error" id="ErrorNombre" ></span>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            Dirección  <br/>
                            <input class="input-registro" type="text" name="DPostal" >
                            <span class="span-error"></span>

                        </td>
                        <td>
                            Poblacion <br/>
                            <input class="input-registro" type="text" name="Poblacio" >
                            <span class="span-error"></span>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            Código Postal <br/>
                            <input class="input-registro" type="text" name="CPostal" ></td>
                            <span class="span-error"></span>

                        <td>
                            Telefono movil <br/>
                            <input class="input-registro" type="phone" name="TMovil" >
                            <span class="span-error"></span>

                        </td>
                    </tr>
                    <tr>
                            <td>Telefono fijo <br/>
                            <input class="input-registro" type="phone" name="TFijo" ></td>
                            <span class="span-error"></span>

                            <td>
                                Fecha de Nacimieto <br/>
                                <input class="input-registro" type="date" name="FNacimiento" >
                                <span class="span-error"></span>

                            </td>
                    </tr>
                    <tr>
                            <td>
                                Contraseña * <br/>
                                <input class="input-registro" type="password" id="Password" name="Password" >
                                <span class="span-error" id="ErrorPassword"></span>

                            </td>
                            <td>
                                Repetir Contraseña * <br/>
                                <input class="input-registro" type="password" id="Password2" name="Password" >
                                <span class="span-error" id="ErrorPassword2" ></span>


                                   
                            </td>
                    </tr>
                    <tr>
                            <td>
                            Correo Electronico * <br/>
                                <input class="input-registro" type="email"  id="Correo" name="Correo" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" />
                                <span class="span-error" id="ErrorCorreo"></span>

                                    
                            </td>
                    </tr>
                    <tr>
                         <td class="Grises">Los campos con asteriscos son obligatorios (*) </td>
                     </tr>
                    <tr>
                        <td><label id="label-Pdatos">Protección de datos:*</label><input type="checkbox" id="PDatos" name="PDatos" ></td>

                    </tr>
                    <tr>
                        <td>
                            <span class="span-error" id="ErrorPDatos"></span>

                            <input class="input-registro" type="submit" name="" value="Aceptar">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <span class="span-error" id="ErrorPDatos"></span>
                        </td>
                    </tr>
            </table>
        </form>
    </div>
    <div id="footer-registro">
     <?php

         include'footer.php'; 
     ?>
     </div>
    </div>
</body>
</html>