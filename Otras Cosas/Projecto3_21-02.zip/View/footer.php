<footer>
	<div id="container_Footer" class="ofset_3_left ofset_3_right">
		<span>&copy; 2019 PS4 SHOP | <a href="cookie.php">Cookies</a></span>
		<button id="up_Button_Footer"></button>
		<label for="up_Button_Footer">Ir Arriba</label>
	</div>
<div id="barra">
            <div id="barraInterior">
                Se utilizan cookies propias y de terceros para mejorar su experiencia de navegación, así como para realizar tareas de analítica. Si continúa navegando entendemos que acepta nuestra. <a href="cookies.pdf" target="_blank" style="padding-left:5px;text-decoration:none;color:#ffffff;">
                	Política de cookies
                </a>
                <a href="javascript:void(0);" style="padding:4px;background:#39b54a;text-decoration:none;color:#fff;" onclick="aceptar_cookies();">Aceptar</a>
            </div>
        </div>
</footer>
